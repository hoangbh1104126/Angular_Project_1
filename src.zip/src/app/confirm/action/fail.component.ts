import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fail',
  templateUrl: './fail.component.html',
  styleUrls: ['./check.component.scss']
})
export class checkFailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
