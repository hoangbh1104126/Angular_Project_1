import { CheckPipe } from './check.pipe';

describe('CheckPipe', () => {
  it('create an instance', () => {
    const pipe = new CheckPipe();
    expect(pipe).toBeTruthy();
  });
});
